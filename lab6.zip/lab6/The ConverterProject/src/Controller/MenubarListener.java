package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import View.ConvertPanel;

/**
* The listener of menu bar is for receiving user's input. 
* user can save input centimeters or using Alt+F
*/

public class MenubarListener implements ActionListener{
	
	/**
	 * Declare a panel and use this panel as interface
	 */
	private ConvertPanel Panel;
	/**
	    * Constructor of this class
	    * @param ConvertPanel
	    * invariant: panel is not change
	    * pre-condition: Panel should be ConvertPanel
	    * post-condition: connect this with panel
	    */
	public MenubarListener(ConvertPanel panel) {
		this.Panel = panel;
	}

	
	/**
	* This method listen to the menu bar input.
	* @param the value of which button being activated.
	* pre-condition: input should be mouse click
	* post-condition: performing the excute() method in ConvertPanel class
	* invariant: method excute once menu bar clicked
	*/
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "SAVE":
			Panel.excute();
		}
	}

}
