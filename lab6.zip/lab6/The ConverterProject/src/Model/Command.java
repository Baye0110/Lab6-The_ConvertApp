package Model;

/**
 * Receiver Class perform the action convert associated with the request
 * For convert method, create subject with his observer in order to combine two design patterns
 * @author Yongjie Ba
 *
 */
public class Command {

	/**
	 * convert class, implement with observer pattern
	 * changing will automatically notify to other observers 
	 * @param input integer
	 * pre-condition: input should be positive integer
	 * post-condition: input will be translated to its observer class
	 * Invariant: user's input will be translated to feet and meter
	 * 
	 */
	public void convert(int input) {
		ValueToConvert subject = new ValueToConvert();
		new FeetObserver(subject);
		new MeterObserver(subject);
		System.out.printf("User input is: %d\n",input);
		subject.setCentieter(input);
	}
}
