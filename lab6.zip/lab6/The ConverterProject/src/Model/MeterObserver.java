package Model;

/**
 * concrete observer class
 * This is a meterObserver class which is extends the observer class
 * @author Yongjie Ba
 *
 */
public class MeterObserver extends Observer{
	public static Double result;
	/**
	 * This is the constructor, ValueToConvert is used as its parameter
	 * will add observer into the list
	 * @param subject
	 * pre-condition: input should be ValueToConvert
	 * post-condition: subject will add this as its observer
	 * invariant: this becomes observer of input
	 */
	public MeterObserver(ValueToConvert subject) {
		this.subject = subject;
		this.subject.attach(this);
	}
	
	
	/**
	 * override update class
	 * post-condition: centimeter will be changed to meters
	 * Invariant: centimeter will changed to meter
	 */
	@Override
	public void update() {
		// TODO Auto-generated method stub
		result = (double)subject.getCentimeter()/100;
		System.out.printf("Convert to meter: %.2f m\n", result);
	}
}
