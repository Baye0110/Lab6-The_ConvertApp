package Model;

/**
 * Invoker class  ask the command to perform the request
 * @author Yongjie Ba
 *
 */
public class MenuOptions {
	/**
	 * initiate ActionListenerCommand class as a object
	 */
	ActionListenerCommand convertCommand;
	
	/**
	 * used to save parameters to class's parameter
	 * @param convertCommand
	 * pre-condition: input should be ActionListenerCommand
	 * post-condition: this class's parameter change to input
	 * Invariant: this class's parameter change to input
	 */
	public MenuOptions(ActionListenerCommand convertCommand){
		this.convertCommand = convertCommand;
	}
	
	/**
	 * clickConvert method, used to excute command;
	 * post-condition: ActionListenerCommand's method excuted
	 */
	
	public void clickConvert() {
		convertCommand.excute();
	}
}
