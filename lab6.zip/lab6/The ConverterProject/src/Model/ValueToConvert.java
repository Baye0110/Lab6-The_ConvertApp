package Model;

import java.util.ArrayList;
import java.util.List;


/**
 * Concrete subject class
 * This class is a subject in Observer pattern
 * @author Yongjie Ba
 *
 */
public class ValueToConvert {
	
	/**
	 * create a Array list to save observers
	 */
	
	private List<Observer> observers = new ArrayList<Observer>();
	
	/**
	 * centimeters in integer
	 * invariant: positive integer
	 */
	
	private int centimeter;
	
	/**
	 * This method can get the centimeter
	 * @return centimeter in integer
	 * post-condition: get the centimeter
	 * invariant: always get the centimeter
	 */
	public int getCentimeter() {
		return centimeter;
	}
	/**
	 * This is method is build for set centimeters and notify other observers
	 * @param centimeter
	 * pre-condition: centimeter should be positive integer
	 * post-condition: this.centimeter changes to given centimeter
	 * Invariant: all changes will notify its observer
	 */
	public void setCentieter(int centimeter) {
		this.centimeter = centimeter;
		notifyAllObservers();
	}
	
	/**
	 * Add observers in the list
	 * @param observer
	 * pre-condition: input should be Observer
	 * post-condition: observer will be added to the list
	 * Invariant: observer will be added to the list
	 */
	public synchronized void attach(Observer observer){
	      observers.add(observer);      
	   }
	 
	/**
	 * This method is used to notify all observer which is in the list
	 * post-condition: all observer saved in the list, will be notified by the subject
	 * Invariant: all observer will be notified by subject
	 */
	public void notifyAllObservers(){
	      for (Observer observer : observers) {
	         observer.update();
	      }
	 } 
}




