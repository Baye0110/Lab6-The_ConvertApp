package Model;

/**
 * interface used as command pattern that will act as a Command
 * @author Yongjie Ba
 *
 */
public interface ActionListenerCommand {
	/**
	 * will be overwrite in other classes
	 */
	public void excute();
}
