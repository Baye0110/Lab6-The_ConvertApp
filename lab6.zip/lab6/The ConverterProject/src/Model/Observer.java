package Model;

/**
 * this is a abstract class, which is observer in Observer Pattern
 * @author Yongjie Ba
 *
 */
public abstract class Observer {
	/**
	 * This class owned subject class of ValueToConvert
	 */
	protected ValueToConvert subject;
	
	/**
	 * update interface,which will extends its child class
	 */
	public abstract void update();
}
