package Model;

/**
 * Concrete observer class
 * This is a feetObserver class which is extends the observer class
 * @author Yongjie Ba
 *
 */
public class FeetObserver extends Observer{
	public static  Double result;
	/**
	 * This is the constructor, ValueToConvert is used as its parameter
	 * will add observer into the list
	 * @param subject
	 * pre-condition:subject should be ValueToConvert
	 * post-condition: subject will add this as its observer
	 * Invariant: this class becomes observer of subject
	 */
	public FeetObserver(ValueToConvert subject) {
		this.subject = subject;
		this.subject.attach(this);
	}

	
	/**
	 * override update class
	 * post-condition: centimeter will be translated to feet
	 */
	@Override
	public void update() {
		// TODO Auto-generated method stub
		result = (double)subject.getCentimeter()/30.48;
		System.out.printf("Convert to Feet: %.11f ft\n", result);
	}

}
