package Model;

/**
 * Concrete Command: ActionConvert
 * @author Yongjie Ba
 *
 */
public class ActionConvert implements ActionListenerCommand{
	/**
	 * owns the Command
	 */
	private Command cmd;
	
	/**
	 * user's input as convert input
	 */
	private int input;

	/**
	 * This method will save the parameters to the class's parameter
	 * @param cmd
	 * @param input
	 * pre-condition: input should be positive integer
	 * post-condition: command and input saved in this class's parameter
	 * Invariant: ActionConvert saves two parameter
	 */
	public ActionConvert(Command cmd,int input) {
		this.cmd = cmd;
		this.input = input;
	}
	
	
	/**
	 * override method of execute and can be executed to convert input
	 * post-condition: input is translated to command class and perform the convert method of command
	 */
	@Override
	public void excute() {
		// TODO Auto-generated method stub
		cmd.convert(input);
	}

}
