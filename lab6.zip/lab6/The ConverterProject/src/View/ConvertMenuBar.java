package View;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;


/**
 * This is class is used to create menu bar for the UI
 * @author Yongjie Ba
 *
 */
public class ConvertMenuBar extends JMenuBar{
	/**
	 * This method is used to create menu list and add item into it
	 * connect with ActionListener and Set the key Alt + F
	 * finally add the menu bar in the pattern
	 * @param menuBarListener
	 */
	public ConvertMenuBar(ActionListener menuBarListener) {
		super();
		JMenu convertMenu = new JMenu("Update model");
		JMenuItem menuItem =  new JMenuItem("Save input centimeters");
		KeyStroke keyStrokeToOpen = KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.ALT_DOWN_MASK);
		menuItem.setAccelerator(keyStrokeToOpen);
		menuItem.setActionCommand("SAVE");
		menuItem.addActionListener(menuBarListener);
		convertMenu.add(menuItem);
		
		super.add(convertMenu);
	}
	
}
