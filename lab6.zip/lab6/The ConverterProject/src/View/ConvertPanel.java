package View;

import java.awt.Color;

import javax.swing.*;

import Model.ActionConvert;
import Model.ActionListenerCommand;
import Model.Command;
import Model.FeetObserver;
import Model.MenuOptions;
import Model.MeterObserver;

/**
 * this class is used to add item into the panel, such as three square to display the number, which is extends JPanel
 * @author Yongjie Ba
 *
 */
public class ConvertPanel extends JPanel{
	
	/**
	 * Three JTextArea used to display feet,meter and centimeters separately.
	 * set as static, which is easy to use
	 */
	
	public static JTextArea FeetConversionArea;
	public static JTextArea MeterConversionArea;
	public static JTextArea CentimetersConversionArea;
	

	/**
	 * constructor
	 * Three JTextArea will be build automatically after this class initiating
	 * post-condition: three JTextArea are created
	 * Invariant: three JTextArea are created
	 */
	public ConvertPanel() {
		super(null);
		FeetConversionArea = new JTextArea(20,20);
		MeterConversionArea = new JTextArea(20,20);
		CentimetersConversionArea = new JTextArea(20,20);
		
		FeetConversionArea.setBackground(Color.green);
		MeterConversionArea.setBackground(Color.orange);
		CentimetersConversionArea.setBackground(Color.yellow);
		
		FeetConversionArea.setBounds(95,0, 200,200); 
		MeterConversionArea.setBounds(305,0, 200,200); 
		CentimetersConversionArea.setBounds(200,210, 200,200); 

		FeetConversionArea.setText("0 ft");
		MeterConversionArea.setText("0 m");
		CentimetersConversionArea.setText("0");
		
		this.add(FeetConversionArea);
		this.add(MeterConversionArea);
		this.add(CentimetersConversionArea);
		

	}
	
	/**
	 * Used as Client class for command pattern
	 * Receive the input from user and send the centimeters to his observers
	 * post-condition: user's input will be translated to deet and meter, and will be showed on the Two JTextArea
	 * Invariant: same as post-condition
	 */
	public void excute() {
		Command cmd = new Command();
		ActionListenerCommand clickConvert = new ActionConvert(cmd,Integer.parseInt(CentimetersConversionArea.getText()));
		
		MenuOptions menu = new MenuOptions(clickConvert);
		menu.clickConvert();
		/**
		 * can be removed
		 */
		FeetConversionArea.setText(FeetObserver.result + " ft");
		MeterConversionArea.setText(MeterObserver.result +" m");
	}
	
	
}
