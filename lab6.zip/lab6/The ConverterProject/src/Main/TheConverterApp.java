package Main;

import javax.swing.*;
import Controller.MenubarListener;
import View.ConvertMenuBar;
import View.ConvertPanel;

/**
 * This class is used to execute the whole program
 * used to display the UI
 * @author Yongjie Ba
 *
 */

public class TheConverterApp {

	/**
	 * main method to create UI
	 * @param args array of string
	 * pre-condition: run as program
	 * post-condition: UI created and visible
	 * invariant: UI visible once this method excuted
	 */
	public static void main(String[] args) {
		JFrame converFrame = new JFrame("Convert");
		ConvertPanel convertPanel = new ConvertPanel();
		MenubarListener menubarListener = new MenubarListener(convertPanel);
		ConvertMenuBar convertMenuBar = new ConvertMenuBar(menubarListener);
		converFrame.add(convertPanel);
		converFrame.setJMenuBar(convertMenuBar);
		converFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		converFrame.setSize(600, 600);
		converFrame.setVisible(true);
	}

}
